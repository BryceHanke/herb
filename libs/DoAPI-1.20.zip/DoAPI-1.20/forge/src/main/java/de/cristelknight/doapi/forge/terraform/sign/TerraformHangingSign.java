package de.cristelknight.doapi.forge.terraform.sign;

import net.minecraft.resources.ResourceLocation;

public interface TerraformHangingSign extends TerraformSign {
	ResourceLocation getGuiTexture();
}
