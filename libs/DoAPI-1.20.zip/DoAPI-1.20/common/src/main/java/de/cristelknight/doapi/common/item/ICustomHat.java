package de.cristelknight.doapi.common.item;

import net.minecraft.resources.ResourceLocation;

@Deprecated
public interface ICustomHat {
    ResourceLocation getTexture();

    Float getOffset();
}
