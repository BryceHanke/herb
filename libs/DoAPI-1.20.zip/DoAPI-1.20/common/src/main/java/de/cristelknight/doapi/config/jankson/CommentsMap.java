package de.cristelknight.doapi.config.jankson;

import com.mojang.serialization.MapLike;

public interface CommentsMap<A> extends MapLike<A>, Comments {
}
